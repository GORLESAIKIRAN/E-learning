<?php include("header.php"); ?>

<!-- Page Sub Menu
		============================================= -->
		<div id="page-menu">

			<div id="page-menu-wrap">

			</div>

		</div><!-- #page-menu end -->


		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">

					<!-- Post Content
					============================================= -->
					<div class="nobottommargin clearfix">

					// Watch Video for Code

					<div class="panel panel-default">
  						<div class="panel-heading">
    						<h3 class="panel-title"><?php echo $lectureName; ?></h3>
  						</div>
  						<div class="panel-body">
    						<?php echo $lecureContent; ?>
  						</div>
					</div>





</div>
</div>
</div>
</section>


<?php include("footer.php"); ?>