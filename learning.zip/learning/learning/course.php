<?php include("header.php"); ?>

		<!-- Page Title
		============================================= -->
		<section id="page-title">

			<div class="container clearfix">
				<h1>Some courses are <strong>Comming Soon...!</strong></h1>
				<span>Exceptional Courses</span>
			</div>

		</section><!-- #page-title end -->

		<!-- Page Sub Menu
		============================================= -->
		<div id="page-menu">

			<div id="page-menu-wrap">


			</div>

		</div><!-- #page-menu end -->

		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">

					<div class=" bottommargin clearfix ">

						<div class="row">
							// Watch Code from Video
						  
					</div>
				</div>		
			</div>
		</div>
	</section>

<?php include("footer.php"); ?>